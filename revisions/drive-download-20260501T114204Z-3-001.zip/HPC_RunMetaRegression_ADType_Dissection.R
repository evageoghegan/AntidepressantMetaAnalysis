#This code document includes the code for a function that is designed to run a basic meta-analysis of Log2FC and sampling variance values using our previously generated objects MetaAnalysis_FoldChanges & MetaAnalysis_SV
#Megan Hagenauer
#Original version: July 25 2024
#In response to reviewers' comments, this function has been updated to include co-variates
#Updated version: March 10, 2026

######################

#Grabbing input data and setting the working directory:

setwd("~/Library/CloudStorage/GoogleDrive-hagenaue@umich.edu/My Drive/BrainAlchemyProject/ProjectFolders/2024_EvaGeoghegan_Antidepressants_Hippocampus/ROutput_And_Results/Revisions")

# load("~/Library/CloudStorage/GoogleDrive-hagenaue@umich.edu/My Drive/BrainAlchemyProject/ProjectFolders/2024_EvaGeoghegan_Antidepressants_Hippocampus/R_Code_And_Workspaces/Meta-analysis/HPC_November_Final_Meta_Analysis.RData")

# setwd("~/Library/CloudStorage/GoogleDrive-hagenaue@umich.edu/My Drive/BrainAlchemyProject/ProjectFolders/2024_EvaGeoghegan_Antidepressants_Hippocampus/ROutput_And_Results/Revisions")

setwd("~/Library/CloudStorage/GoogleDrive-hagenaue@umich.edu/My Drive/BrainAlchemyProject/ProjectFolders/2024_EvaGeoghegan_Antidepressants_Hippocampus/ROutput_And_Results/Revisions/HPC/MetaRegression_ADType_Dissection")

load("~/Library/CloudStorage/GoogleDrive-hagenaue@umich.edu/My Drive/BrainAlchemyProject/ProjectFolders/2024_EvaGeoghegan_Antidepressants_Hippocampus/ROutput_And_Results/Revisions/HPC/Workspace_Revisions_20260312_MetaRegression_ADType_Dissection.RData")

######################

#Installing and loading relevant code packages:
install.packages("metafor")
library(metafor)
library(plyr) 

######################

ADType<-Covariates$ADType
Dissection<-Covariates$Dissection
Platform<-Covariates$Platform
DepressionModel<-Covariates$DepressionModel

#Platform may make this crash - many of these genes aren't found in the old microarray datasets
  
#Function:

RunBasicMetaAnalysis<-function(NumberOfComparisons, CutOffForNAs, MetaAnalysis_FoldChanges, MetaAnalysis_SV){
  
  #The function first provides information about how many of the statistical contrasts have NA values as their differential expression results for each gene:
  MetaAnalysis_FoldChanges_NAsPerRow<-apply(MetaAnalysis_FoldChanges[,-c(1:3)], 1, function(y) sum(is.na(y)))
  
  print("Table of # of NAs per Row (Gene):")
  print(table(MetaAnalysis_FoldChanges_NAsPerRow))
  
  #Then any row (gene) that has too many NAs is removed from the analysis:
  MetaAnalysis_FoldChanges_ForMeta<<-MetaAnalysis_FoldChanges[MetaAnalysis_FoldChanges_NAsPerRow<CutOffForNAs,]
  MetaAnalysis_SV_ForMeta<<-MetaAnalysis_SV[MetaAnalysis_FoldChanges_NAsPerRow<CutOffForNAs,]
  
  print("MetaAnalysis_FoldChanges_ForMeta:")
  print(str(MetaAnalysis_FoldChanges_ForMeta))
  
  #I'm going to make an empty matrix to store the results of my meta-analysis:
  #This matrix was originally 6 columns
  #It was made larger to incorporate heterogeneity statistics (8 stats)
  #And then even larger to include stats for the covariates
  metaOutput<-matrix(NA, nrow(MetaAnalysis_FoldChanges_ForMeta), 27)
  
  #And then run a loop that run's a meta-analysis on the differential expression results (i.e., the columns that aren't annotation) for each gene (row):
  for(i in c(1:nrow(MetaAnalysis_FoldChanges_ForMeta))){
    
    print(i)
    
    #When pulling out the log2FC values and sampling variances (SV) for each gene, we use the function as.numeric to make sure they are in numeric matrix format because this is the required input format for the meta-analysis function that we will use:
    effect<-as.numeric(MetaAnalysis_FoldChanges_ForMeta[i,-c(1:3)])
    var<-as.numeric(MetaAnalysis_SV_ForMeta[i,-c(1:3)])
    
    #I added a function tryCatch that double-checks that the meta-analysis function (rma) doesn't produce errors (which breaks the loop):
    
    #Making the loop skip to the next gene if there isn't data for one of the co-variates:
    if( (min(table(is.na(effect), Dissection)[1,])<1)){}else{
    
    skip_to_next <- FALSE
    tryCatch(TempMeta<-rma(yi=effect~ADType+Dissection, vi=var), error = function(e) {skip_to_next <<- TRUE})
    
    #If everything looks good, we move on to running the meta-analysis using a model that treats the variation in Log2FC across studies as random effects:
    if(skip_to_next){}else{
      TempMeta<-rma(yi=effect~ADType+Dissection, vi=var)
      metaOutput[i, c(1:3)]<-TempMeta$b #gives estimate Log2FC
      metaOutput[i, c(4:6)]<-TempMeta$se #gives standard error
      metaOutput[i, c(7:9)]<-TempMeta$pval #gives pval
      metaOutput[i, c(10:12)]<-TempMeta$ci.lb #gives confidence interval lower bound
      metaOutput[i, c(13:15)]<-TempMeta$ci.ub #gives confidence interval upper bound
      metaOutput[i, 16]<-NumberOfComparisons-sum(is.na(effect))#Number of comparisons with data
      metaOutput[i, 17]<-TempMeta$k #Metafor output: number of studies (contrasts) included in the analysis - sanity check, should be the same as column 6
      metaOutput[i, 18]<-TempMeta$p #Metafor output: number of coefficients in model
      metaOutput[i, 19]<-TempMeta$tau2 #estimated amount of (residual) heterogeneity
      metaOutput[i, 20]<-TempMeta$se.tau2 #SE of the estimated amount of (residual) heterogeneity
      metaOutput[i, 21]<-TempMeta$QE #When moderators are included in the model, this is the QE-test for residual heterogeneity
      metaOutput[i, 22]<-TempMeta$QEp #p-value of the test for (residual) heterogeneity (Cochran’s Q-test)
      metaOutput[i, 23]<-TempMeta$I2 #the I 2 statistic, which estimates (in percent) how much of the total variability in the observed effect sizes or outcomes can be attributed to heterogeneity among the true effects
      metaOutput[i, 24]<-TempMeta$H2 #the H2 statistic, which estimates the ratio of the total amount of variability in the observed effect sizes or outcomes to the amount of sampling variability
      metaOutput[i, 25]<-TempMeta$QM #test statistic of the omnibus test of moderators
      metaOutput[i, 26]<-TempMeta$QMp #corresponding p-value of the omnibus test of moderators
      metaOutput[i, 27]<-TempMeta$R2 #amount of heterogeneity accounted for by the moderators
      
      rm(TempMeta)
    }}
    rm(effect, var)
  }
  
  #Naming the columns in our output:
  colnames(metaOutput)<-c("Log2FC_AD_vs_Ctrl", "Log2FC_ADType_NonTradvsTrad", "Log2FC_Dissection_DG_vs_HPC",         
                          "SE_AD", "SE_ADType", "SE_Dissection", 
                          "pval_AD", "pval_ADType","pval_Dissection",
                          "CI_lb_AD", "CI_lb_ADType","CI_lb_Dissection",
                          "CI_ub_AD", "CI_ub_ADType","CI_ub_Dissection", 
                          "Number_Of_Comparisons", "Number_of_ Contrasts", "Number_of_Coefficients", "tau2_ResidualHeterogeneity", "SE_tau2_ResidualHeterogeneity", "QE_CochransQ_Teststat", "QEp_CochransQ_pval", "I2_PercentVar_TrueHeterogeneity", "H2_Ratio_EffectHetero_overSamplVar", "QM_ModeratorOmnibusTest", "QMp_Pval_ModeratorOmnibusTest", "R2_ModeratorVarianceExplained")
  
  #The row names for our output are the combined mouse-rat entrez ids: 
  row.names(metaOutput)<-MetaAnalysis_FoldChanges_ForMeta[,3]
  
  #We return this output back into our global environment
  metaOutput<<-metaOutput
  MetaAnalysis_Annotation<<-MetaAnalysis_FoldChanges_ForMeta[,c(1:3)]

  return(metaOutput)
  return(MetaAnalysis_Annotation)
  
  #... and provide the user with an update about the newly created object:
  
  print("metaOutput:")
  print(str(metaOutput))
  
  print("Top of metaOutput:")
  print(head(metaOutput))
  
  print("Bottom of metaOutput")
  print(tail(metaOutput))
  
}

######################

#Example Usage:

NumberOfComparisons=22
CutOffForNAs=12
#I have 22 comparisons
#12 NA is too many

metaOutput<-RunBasicMetaAnalysis(NumberOfComparisons, CutOffForNAs, MetaAnalysis_FoldChanges, MetaAnalysis_SV)
#Note: this function can take a while to run, especially if you have a lot of data  
#Plug in your computer, take a break, grab some coffee...

######################

#Example Output:

str(metaOutput)
# num [1:16494, 1:27] -0.03076 -0.04894 -0.05688 -0.03514 0.00672 ...
# - attr(*, "dimnames")=List of 2
# ..$ : chr [1:16494] "23825_114087" "18585_191569" "66514_246307" "20480_65041" ...
# ..$ : chr [1:27] "Log2FC_AD_vs_Ctrl" "Log2FC_ADType_NonTradvsTrad" "Log2FC_Dissection_DG_vs_HPC" "SE_AD" ...

head(metaOutput)

# Log2FC_AD_vs_Ctrl Log2FC_ADType_NonTradvsTrad Log2FC_Dissection_DG_vs_HPC      SE_AD  SE_ADType
# 23825_114087      -0.030764044                -0.103571289                -0.086756424 0.02210376 0.04516652
# 18585_191569      -0.048941469                 0.047201510                 0.008737804 0.04560747 0.09771650
# 66514_246307      -0.056883279                 0.037977286                -0.102129563 0.02292225 0.04830485
# 20480_65041       -0.035135856                -0.039796933                -0.070005254 0.01665281 0.03720774
# 13726_25437        0.006722524                -0.003103852                 0.014863227 0.01650638 0.02703696
# 16952_25380        0.002300587                 0.011860089                -0.057810392 0.02329522 0.04768007
# SE_Dissection    pval_AD pval_ADType pval_Dissection    CI_lb_AD CI_lb_ADType CI_lb_Dissection
# 23825_114087    0.03939608 0.16398261  0.02184233      0.02765410 -0.07408663  -0.19209604      -0.16397133
# 18585_191569    0.09504068 0.28322529  0.62906347      0.92674768 -0.13833046  -0.14431931      -0.17753851
# 66514_246307    0.04772073 0.01308033  0.43175017      0.03234257 -0.10181007  -0.05669848      -0.19566047
# 20480_65041     0.03670473 0.03486644  0.28480503      0.05648770 -0.06777476  -0.11272276      -0.14194521
# 13726_25437     0.03585800 0.68381098  0.90860338      0.67850617 -0.02562938  -0.05609531      -0.05541715
# 16952_25380     0.04494148 0.92133049  0.80355951      0.19832153 -0.04335721  -0.08159114      -0.14589407
# CI_ub_AD CI_ub_ADType CI_ub_Dissection Number_Of_Comparisons Number_of_ Contrasts
# 23825_114087  0.012558536  -0.01504653     -0.009541523                    22                   22
# 18585_191569  0.040447520   0.23872233      0.195014122                    21                   21
# 66514_246307 -0.011956493   0.13265305     -0.008598653                    22                   22
# 20480_65041  -0.002496957   0.03312890      0.001934704                    22                   22
# 13726_25437   0.039074429   0.04988761      0.085143608                    22                   22
# 16952_25380   0.047958380   0.10531132      0.030273283                    21                   21
# Number_of_Coefficients tau2_ResidualHeterogeneity SE_tau2_ResidualHeterogeneity QE_CochransQ_Teststat
# 23825_114087                      3               1.791608e-03                  0.0022012999              28.34940
# 18585_191569                      3               3.064619e-02                  0.0135109306              85.19450
# 66514_246307                      3               5.533430e-03                  0.0032418152              45.30738
# 20480_65041                       3               1.069248e-03                  0.0017073535              23.47928
# 13726_25437                       3               0.000000e+00                  0.0007321004              16.93967
# 16952_25380                       3               1.334682e-06                  0.0028905371              20.64606
# QEp_CochransQ_pval I2_PercentVar_TrueHeterogeneity H2_Ratio_EffectHetero_overSamplVar
# 23825_114087       7.693125e-02                     25.32815483                           1.339193
# 18585_191569       1.040909e-10                     80.78752422                           5.204951
# 66514_246307       6.206328e-04                     59.39619971                           2.462824
# 20480_65041        2.168903e-01                     19.36405890                           1.240142
# 13726_25437        5.939551e-01                      0.00000000                           1.000000
# 16952_25380        2.976444e-01                      0.01152641                           1.000115
# QM_ModeratorOmnibusTest QMp_Pval_ModeratorOmnibusTest R2_ModeratorVarianceExplained
# 23825_114087               7.7217632                    0.02104943                      63.99832
# 18585_191569               0.2404069                    0.88674003                       0.00000
# 66514_246307               7.4991941                    0.02352722                      34.00801
# 20480_65041                3.6779763                    0.15897821                       0.00000
# 13726_25437                0.2630040                    0.87677753                     100.00000
# 16952_25380                1.9106674                    0.38468375                      65.83321

tail(metaOutput)

# Log2FC_AD_vs_Ctrl Log2FC_ADType_NonTradvsTrad Log2FC_Dissection_DG_vs_HPC      SE_AD SE_ADType SE_Dissection
# 14934_NA        0.081265145                  0.17466498                 0.051482674 0.06314797 0.1352827    0.06002718
# 20568_NA       -0.003843115                 -0.05531502                -0.130371596 0.13263730 0.2739577    0.14396754
# 21991_NA       -0.037327712                 -0.07959866                 0.003878028 0.02867464 0.0576214    0.03495567
# 246086_NA      -0.048567788                 -0.02890875                 0.010466371 0.06039446 0.1332680    0.06044013
# 66166_NA        0.035098162                  0.03434766                 0.008751319 0.10343944 0.2225865    0.12744384
# 97848_NA       -0.014578084                 -0.08183876                -0.085141834 0.10858525 0.2258181    0.11698156
# pval_AD pval_ADType pval_Dissection    CI_lb_AD CI_lb_ADType CI_lb_Dissection   CI_ub_AD CI_ub_ADType
# 14934_NA  0.1981290   0.1966653       0.3910824 -0.04250260  -0.09048432      -0.06616843 0.20503289    0.4398143
# 20568_NA  0.9768848   0.8399864       0.3651675 -0.26380744  -0.59226227      -0.41254280 0.25612121    0.4816322
# 21991_NA  0.1929959   0.1671535       0.9116629 -0.09352897  -0.19253453      -0.06463382 0.01887355    0.0333372
# 246086_NA 0.4212952   0.8282692       0.8625184 -0.16693875  -0.29010930      -0.10799411 0.06980317    0.2322918
# 66166_NA  0.7343753   0.8773642       0.9452539 -0.16763942  -0.40191395      -0.24103401 0.23783575    0.4706093
# 97848_NA  0.8932011   0.7170457       0.4667221 -0.22740127  -0.52443419      -0.31442148 0.19824510    0.3607567
# CI_ub_Dissection Number_Of_Comparisons Number_of_ Contrasts Number_of_Coefficients
# 14934_NA        0.16913378                    11                   11                      3
# 20568_NA        0.15179961                    11                   11                      3
# 21991_NA        0.07238987                    11                   11                      3
# 246086_NA       0.12892685                    11                   11                      3
# 66166_NA        0.25853665                    11                   11                      3
# 97848_NA        0.14413781                    11                   11                      3
# tau2_ResidualHeterogeneity SE_tau2_ResidualHeterogeneity QE_CochransQ_Teststat QEp_CochransQ_pval
# 14934_NA                1.300364e-03                   0.002163501             11.068443       1.978512e-01
# 20568_NA                3.363234e-02                   0.022877048             30.557851       1.683685e-04
# 21991_NA                4.298982e-04                   0.001425328              8.079124       4.257794e-01
# 246086_NA               4.427184e-06                   0.001549318             15.568237       4.899375e-02
# 66166_NA                2.001904e-02                   0.015131788             40.489592       2.596392e-06
# 97848_NA                2.172575e-02                   0.014583450             48.590107       7.617855e-08
# I2_PercentVar_TrueHeterogeneity H2_Ratio_EffectHetero_overSamplVar QM_ModeratorOmnibusTest
# 14934_NA                        30.115932                           1.430941              1.83761645
# 20568_NA                        84.661974                           6.519744              0.82903725
# 21991_NA                        13.915444                           1.161649              2.23194663
# 246086_NA                        0.087105                           1.000872              0.13266572
# 66166_NA                        77.035867                           4.354617              0.02385719
# 97848_NA                        83.310873                           5.991925              0.54620703
# QMp_Pval_ModeratorOmnibusTest R2_ModeratorVarianceExplained
# 14934_NA                      0.3989943                       0.00000
# 20568_NA                      0.6606582                       0.00000
# 21991_NA                      0.3275963                       0.00000
# 246086_NA                     0.9358193                      45.93275
# 66166_NA                      0.9881423                       0.00000
# 97848_NA                      0.7610140                       0.00000

write.csv(metaOutput, "metaOutput_wCovariates_ADType_Dissection.csv")
write.csv(MetaAnalysis_Annotation, "MetaAnalysis_Annotation_for_metaOutput_wCovariates_ADType_Dissection.csv")

colnames(metaOutput)

#############################

#I should probably run an FDR correction for all of these pvalues
#That function needs to be adapted too


if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("multtest")                                 
library(multtest)


dim(metaOutput)
colnames(metaOutput)

####################

#Function:

FalseDiscoveryCorrection<-function(metaOutput, HOM_MouseVsRat, MetaAnalysis_Annotation){
  
  #For the meta-analysis pval:
  
  #This calculates the false discovery rate, or q-value, for each of our p-values using the Benjamini-Hochberg procedure:
  tempPvalAdjMeta<-mt.rawp2adjp(metaOutput[,7], proc=c("BH"))
  
  #Then we put those results back into the order of our orginal output:
  metaPvalAdj<-tempPvalAdjMeta$adjp[order(tempPvalAdjMeta$index),]
  
  #And bind the false discovery rate (FDR) to the rest of the meta-analysis output:
  metaOutputFDR<-cbind(metaOutput, metaPvalAdj[,2])
  
  #And name that column FDR:
  colnames(metaOutputFDR)[28]<-"AD_FDR"
  
  rm(tempPvalAdjMeta, metaPvalAdj)
  
  #For the ADType:
  
  #This calculates the false discovery rate, or q-value, for each of our p-values using the Benjamini-Hochberg procedure:
  tempPvalAdjMeta<-mt.rawp2adjp(metaOutput[,8], proc=c("BH"))
  
  #Then we put those results back into the order of our orginal output:
  metaPvalAdj<-tempPvalAdjMeta$adjp[order(tempPvalAdjMeta$index),]
  
  #And bind the false discovery rate (FDR) to the rest of the meta-analysis output:
  metaOutputFDR<-cbind(metaOutputFDR, metaPvalAdj[,2])
  
  #And name that column FDR:
  colnames(metaOutputFDR)[29]<-"ADType_FDR"
  
  rm(tempPvalAdjMeta, metaPvalAdj)
  
  
  #For Dissection:
  
  #This calculates the false discovery rate, or q-value, for each of our p-values using the Benjamini-Hochberg procedure:
  tempPvalAdjMeta<-mt.rawp2adjp(metaOutput[,9], proc=c("BH"))
  
  #Then we put those results back into the order of our orginal output:
  metaPvalAdj<-tempPvalAdjMeta$adjp[order(tempPvalAdjMeta$index),]
  
  #And bind the false discovery rate (FDR) to the rest of the meta-analysis output:
  metaOutputFDR<-cbind(metaOutputFDR, metaPvalAdj[,2])
  
  #And name that column FDR:
  colnames(metaOutputFDR)[30]<-"Dissection_FDR"
  
  rm(tempPvalAdjMeta, metaPvalAdj)
  
  
  #These results are returned to our global environment:
  metaOutputFDR<<-metaOutputFDR
  
  #We let the user know the basic structure of the meta-analysis output with FDR added to it (just to make sure everything still looks good)
  print("metaOutputFDR:")
  print(str(metaOutputFDR))
  
  #Then we make a dataframe that adds the annotation to that output:
  TempDF<-cbind.data.frame(metaOutputFDR, MetaAnalysis_Annotation)
  #And then adds even more detailed gene annotation:
  
  #First the detailed annotation for the mouse genes:
  TempDF2<-join(TempDF, HOM_MouseVsRat[,c(4:5,9:11)], by="Mouse_EntrezGene.ID", type="left", match="first")
  
  #Next the annnotation for the rat genes:
  TempDF3<-join(TempDF2, HOM_MouseVsRat[,c(15:16,20:22)], by="Rat_EntrezGene.ID", type="left", match="first")
  
  #This is renamed and returned to our global environment:
  metaOutputFDR_annotated<-TempDF3
  metaOutputFDR_annotated<<-metaOutputFDR_annotated
  
  #And written out into our working directory:
  write.csv(metaOutputFDR_annotated, "metaOutputFDR_annotated.csv")
  
  #Then we make a version of the output in order by p-value:
  metaOutputFDR_OrderbyPval<<-metaOutputFDR_annotated[order(metaOutputFDR_annotated[,5]),]
  
  #Let's write out a version of the output in order by p-value:
  write.csv(metaOutputFDR_OrderbyPval, "metaOutputFDR_orderedByPval.csv")
  
  #And give the user some information about their results:
  
  print("Do we have any genes that are statistically significant following traditional false discovery rate correction (FDR<0.05)?")
  print(sum(metaOutputFDR_annotated[,30]<0.05, na.rm=TRUE))
  
  print("What are the top results?")
  print(head(metaOutputFDR_annotated[order(metaOutputFDR_annotated[,35]),]))
  
  
}


FalseDiscoveryCorrection(metaOutput, HOM_MouseVsRat, MetaAnalysis_Annotation)


# [1] "metaOutputFDR:"
# num [1:16494, 1:30] -0.03076 -0.04894 -0.05688 -0.03514 0.00672 ...
# - attr(*, "dimnames")=List of 2
# ..$ : chr [1:16494] "23825_114087" "18585_191569" "66514_246307" "20480_65041" ...
# ..$ : chr [1:30] "Log2FC_AD_vs_Ctrl" "Log2FC_ADType_NonTradvsTrad" "Log2FC_Dissection_DG_vs_HPC" "SE_AD" ...
# NULL
# [1] "Do we have any genes that are statistically significant following traditional false discovery rate correction (FDR<0.05)?"
# [1] 374
# [1] "What are the top results?"
# Rat_EntrezGene.ID Mouse_EntrezGene.ID Log2FC_AD_vs_Ctrl Log2FC_ADType_NonTradvsTrad
# 27993_316317             316317               27993      -0.030807487                 -0.04061154
# 16008_25662               25662               16008      -0.129623953                  0.08830303
# 27217_289311             289311               27217      -0.019125897                  0.07178559
# 12227_29619               29619               12227      -0.002762897                 -0.03937261
# 171567_171566            171566              171567      -0.003010445                 -0.01494454
# 17901_56781               56781               17901       0.001138428                  0.10242941
# Log2FC_Dissection_DG_vs_HPC      SE_AD  SE_ADType SE_Dissection   pval_AD pval_ADType pval_Dissection
# 27993_316317                  -0.07780283 0.01490956 0.02806130    0.03205104 0.0388010   0.1478286     0.015204678
# 16008_25662                   -0.23006169 0.09132848 0.18985325    0.18478489 0.1558070   0.6418512     0.213122799
# 27217_289311                   0.12559461 0.02835989 0.05577083    0.04786126 0.5000573   0.1980410     0.008686824
# 12227_29619                   -0.05001962 0.03265586 0.06670815    0.06676610 0.9325743   0.5550419     0.453750612
# 171567_171566                 -0.09464610 0.02077752 0.04339190    0.04168062 0.8847981   0.7305390     0.023162367
# 17901_56781                    0.01242776 0.04900680 0.10133596    0.09513686 0.9814668   0.3121168     0.896067772
# CI_lb_AD CI_lb_ADType CI_lb_Dissection    CI_ub_AD CI_ub_ADType CI_ub_Dissection
# 27993_316317  -0.06002968  -0.09561067      -0.14062171 -0.00158529   0.01438759      -0.01498395
# 16008_25662   -0.30862449  -0.28380250      -0.59223343  0.04937658   0.46040856       0.13211004
# 27217_289311  -0.07471026  -0.03752323       0.03178827  0.03645846   0.18109441       0.21940096
# 12227_29619   -0.06676721  -0.17011818      -0.18087878  0.06124141   0.09137296       0.08083954
# 171567_171566 -0.04373364  -0.09999110      -0.17633862  0.03771275   0.07010201      -0.01295358
# 17901_56781   -0.09491314  -0.09618542      -0.17403707  0.09718999   0.30104425       0.19889258
# Number_Of_Comparisons Number_of_ Contrasts Number_of_Coefficients tau2_ResidualHeterogeneity
# 27993_316317                     21                   21                      3               0.0001591518
# 16008_25662                      21                   21                      3               0.0894016864
# 27217_289311                     16                   16                      3               0.0019974557
# 12227_29619                      21                   21                      3               0.0101743317
# 171567_171566                    22                   22                      3               0.0038208325
# 17901_56781                      22                   22                      3               0.0254941574
# SE_tau2_ResidualHeterogeneity QE_CochransQ_Teststat QEp_CochransQ_pval I2_PercentVar_TrueHeterogeneity
# 27993_316317                   0.0009919391              16.35699       5.676479e-01                        4.401038
# 16008_25662                    0.0472986391              59.20852       2.745042e-06                       70.426601
# 27217_289311                   0.0030062670              17.12652       1.935848e-01                       24.808233
# 12227_29619                    0.0065488760              37.29892       4.790108e-03                       58.849850
# 171567_171566                  0.0026990223              36.60491       8.887517e-03                       47.327406
# 17901_56781                    0.0133949593              83.51519       4.573923e-10                       73.188549
# H2_Ratio_EffectHetero_overSamplVar QM_ModeratorOmnibusTest QMp_Pval_ModeratorOmnibusTest
# 27993_316317                            1.046036                6.110871                    0.04710219
# 16008_25662                             3.381417                2.505133                    0.28577036
# 27217_289311                            1.329933                8.169211                    0.01682978
# 12227_29619                             2.430125                0.746391                    0.68853061
# 171567_171566                           1.898521                5.287565                    0.07109185
# 17901_56781                             3.729750                1.036345                    0.59560800
# R2_ModeratorVarianceExplained    AD_FDR ADType_FDR Dissection_FDR MouseVsRat_EntrezGene.ID Mouse_Symbol
# 27993_316317                       50.30284 0.2978869  0.7031386      0.1234791             27993_316317         Imp4
# 16008_25662                        10.02065 0.5251084  0.9534371      0.4969953              16008_25662       Igfbp2
# 27217_289311                       68.05788 0.8089393  0.7609483      0.0890494             27217_289311        Mixl1
# 12227_29619                         0.00000 0.9867137  0.9345509      0.7137971              12227_29619         Btg2
# 171567_171566                      25.26545 0.9716285  0.9711177      0.1564260            171567_171566         Nme7
# 17901_56781                         0.00000 0.9984035  0.8348913      0.9622898              17901_56781         Myl1
# Mouse_Genetic.Location Mouse_Genome.Coordinates..mouse..GRCm39.human..GRCh38.
# 27993_316317                Chr1  cM                              Chr1:34478558-34484828(+)
# 16008_25662                 Chr1  cM                              Chr1:72863662-72891633(+)
# 27217_289311                Chr1  cM                            Chr1:180520608-180524599(-)
# 12227_29619                 Chr1  cM                            Chr1:134002908-134006858(-)
# 171567_171566               Chr1  cM                            Chr1:164135091-164264870(+)
# 17901_56781                 Chr1  cM                              Chr1:66963454-66984563(-)
# Mouse_Name Rat_Symbol Rat_Genetic.Location
# 27993_316317    IMP4, U3 small nucleolar ribonucleoprotein       Imp4             Chr9 q21
# 16008_25662   insulin-like growth factor binding protein 2     Igfbp2             Chr9 q33
# 27217_289311                      Mix paired-like homeobox      Mixl1            Chr13 q26
# 12227_29619                BTG anti-proliferation factor 2       Btg2            Chr13 q13
# 171567_171566                     NME/NM23 family member 7       Nme7            Chr13 q23
# 17901_56781                    myosin, light polypeptide 1       Myl1             Chr9 q32
# Rat_Genome.Coordinates..mouse..GRCm39.human..GRCh38.                                     Rat_Name
# 27993_316317                                                    NA   IMP U3 small nucleolar ribonucleoprotein 4
# 16008_25662                                                     NA insulin-like growth factor binding protein 2
# 27217_289311                                                    NA                   Mix paired-like homeobox 1
# 12227_29619                                                     NA              BTG anti-proliferation factor 2
# 171567_171566                                                   NA                     NME/NM23 family member 7
# 17901_56781                                                     NA                        myosin, light chain 1

#####################

#Taking a peek

sum(is.na(metaOutputFDR_OrderbyPval$Log2FC_AD_vs_Ctrl))
#[1] 52
#Very little loss


sum(metaOutputFDR_OrderbyPval$ADType_FDR<0.05, na.rm=TRUE)
#[1] 58

sum(metaOutputFDR_OrderbyPval$Dissection_FDR<0.05, na.rm=TRUE)
#[1] 1111

sum(metaOutputFDR_OrderbyPval$AD_FDR<0.05, na.rm=TRUE)
#[1] 374


pdf("Histogram_pvalues_forDissection.pdf", height=5, width=4)
hist(metaOutputFDR_OrderbyPval$pval_Dissection)
dev.off()

pdf("Histogram_pvalues_forADType.pdf", height=5, width=4)
hist(metaOutputFDR_OrderbyPval$pval_ADType)
dev.off()

pdf("Histogram_pvalues_forAD.pdf", height=5, width=4)
hist(metaOutputFDR_OrderbyPval$pval_AD)
dev.off()


#We should probably join that with our already ridiculously massive meta-analysis output to run comparisons

metaOutputFDR_basic<-read.csv("metaOutputFDR_orderedByPval_wHeterogeneityPubBiasRobustness.csv", header=TRUE, stringsAsFactors = FALSE)

metaOutputFDR_cov<-metaOutputFDR_OrderbyPval

colnames(metaOutputFDR_cov)<-paste("wCov", colnames(metaOutputFDR_cov), sep="_")

colnames(metaOutputFDR_cov)[33]<-"MouseVsRat_EntrezGene.ID"  

metaOutputFDR_basic_and_cov<-join(metaOutputFDR_basic, metaOutputFDR_cov, by="MouseVsRat_EntrezGene.ID", type="left")


write.csv(metaOutputFDR_basic_and_cov, "metaOutputFDR_basic_and_cov.csv")

pdf("Scatterplot_MetaAnalysisLog2FC_WCov_vs_WO.pdf", height=5, width=4)
plot(metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl~metaOutputFDR_basic_and_cov$Log2FC_estimate, xlab="Antidepressant Log2FC: no Covariates", ylab="Antidepressant Log2FC: with Covariates")
abline(a=0, b=1, col="grey", lwd=3)
TrendLine<-lm(metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl~metaOutputFDR_basic_and_cov$Log2FC_estimate)
abline(TrendLine, col=2, lwd=3)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl ~ 
#        metaOutputFDR_basic_and_cov$Log2FC_estimate)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.42557 -0.00883  0.00014  0.00905  0.26350 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                                 -0.0019240  0.0001683  -11.43   <2e-16 ***
#   metaOutputFDR_basic_and_cov$Log2FC_estimate  1.0895043  0.0036173  301.19   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.02155 on 16401 degrees of freedom
# (91 observations deleted due to missingness)
# Multiple R-squared:  0.8469,	Adjusted R-squared:  0.8469 
# F-statistic: 9.071e+04 on 1 and 16401 DF,  p-value: < 2.2e-16

cor.test(metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl, metaOutputFDR_basic_and_cov$Log2FC_estimate, method="spearman", use="pairwise.complete.obs")
# 
# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl and metaOutputFDR_basic_and_cov$Log2FC_estimate
# S = 7.3472e+10, p-value < 2.2e-16
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.9001148 



pdf("Scatterplot_MetaAnalysisLog2FC_ADType_vs_Original.pdf", height=5, width=4)
plot(metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad~metaOutputFDR_basic_and_cov$Log2FC_estimate, xlab="Antidepressant Log2FC: no Covariates", ylab="Antidepressant Type Log2FC")
#abline(a=0, b=1, col="grey", lwd=3)
TrendLine<-lm(metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad~metaOutputFDR_basic_and_cov$Log2FC_estimate)
abline(TrendLine, col=2, lwd=3)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad ~ 
#        metaOutputFDR_basic_and_cov$Log2FC_estimate)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.82783 -0.04313 -0.00120  0.04330  0.84831 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                                 -0.0086915  0.0005828  -14.91   <2e-16 ***
#   metaOutputFDR_basic_and_cov$Log2FC_estimate -0.4371451  0.0125283  -34.89   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.07464 on 16401 degrees of freedom
# (91 observations deleted due to missingness)
# Multiple R-squared:  0.0691,	Adjusted R-squared:  0.06905 
# F-statistic:  1217 on 1 and 16401 DF,  p-value: < 2.2e-16

cor.test(metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad, metaOutputFDR_basic_and_cov$Log2FC_estimate, method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad and metaOutputFDR_basic_and_cov$Log2FC_estimate
# S = 9.1187e+11, p-value < 2.2e-16
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#        rho 
# -0.2396988 

pdf("Scatterplot_MetaAnalysisLog2FC_ADType_vs_Original_FDR10.pdf", height=6, width=5)
plot(wCov_Log2FC_ADType_NonTradvsTrad~Log2FC_estimate, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,], xlab="Antidepressant Log2FC", ylab="Antidepressant Type Log2FC", pch=16, col="grey")
points(wCov_Log2FC_ADType_NonTradvsTrad~Log2FC_estimate, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,])
TrendLine<-lm(wCov_Log2FC_ADType_NonTradvsTrad~Log2FC_estimate, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,])
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = wCov_Log2FC_ADType_NonTradvsTrad ~ Log2FC_estimate, 
#      data = metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR < 
#                                           0.1, ])
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.219308 -0.037432 -0.003625  0.043296  0.199907 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)     -0.014764   0.005964  -2.476   0.0146 *  
#   Log2FC_estimate -0.344564   0.059568  -5.784 5.28e-08 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.06767 on 128 degrees of freedom
# (57 observations deleted due to missingness)
# Multiple R-squared:  0.2072,	Adjusted R-squared:  0.201 
# F-statistic: 33.46 on 1 and 128 DF,  p-value: 5.281e-08

cor.test(metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad[metaOutputFDR_basic_and_cov$FDR<0.10], metaOutputFDR_basic_and_cov$Log2FC_estimate[metaOutputFDR_basic_and_cov$FDR<0.10], method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad[metaOutputFDR_basic_and_cov$FDR < 0.1] and metaOutputFDR_basic_and_cov$Log2FC_estimate[metaOutputFDR_basic_and_cov$FDR < 0.1]
# S = 531264, p-value = 1.022e-07
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#        rho 
# -0.4509661


pdf("Scatterplot_MetaAnalysisLog2FC_ADType_vs_AD.pdf", height=5, width=4)
plot(metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad~metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl, xlab="Antidepressant Log2FC: with Covariates", ylab="Antidepressant Type Log2FC")
#abline(a=0, b=1, col="grey", lwd=3)
TrendLine<-lm(metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad~metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl)
abline(TrendLine, col=2, lwd=3)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad ~ 
#        metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.81285 -0.04511 -0.00074  0.04465  0.82040 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                                        -0.0083861  0.0006035 -13.896   <2e-16 ***
#   metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl  0.0120608  0.0109559   1.101    0.271    
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.0773 on 16440 degrees of freedom
# (52 observations deleted due to missingness)
# Multiple R-squared:  7.371e-05,	Adjusted R-squared:  1.289e-05 
# F-statistic: 1.212 on 1 and 16440 DF,  p-value: 0.271


cor.test(metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad, metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl, method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad and metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl
# S = 7.2778e+11, p-value = 0.02405
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#        rho 
# 0.01759688 


pdf("Scatterplot_MetaAnalysisLog2FC_ADType_vs_AD_FDR10.pdf", height=6, width=5)
plot(wCov_Log2FC_ADType_NonTradvsTrad~wCov_Log2FC_AD_vs_Ctrl, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,], xlab="Antidepressant Log2FC", ylab="Antidepressant Type Log2FC", pch=16, col="grey")
points(wCov_Log2FC_ADType_NonTradvsTrad~wCov_Log2FC_AD_vs_Ctrl, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,])
TrendLine<-lm(wCov_Log2FC_ADType_NonTradvsTrad~wCov_Log2FC_AD_vs_Ctrl, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,])
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = wCov_Log2FC_ADType_NonTradvsTrad ~ wCov_Log2FC_AD_vs_Ctrl, 
#      data = metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR < 
#                                           0.1, ])
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.26113 -0.04487  0.00181  0.04416  0.17325 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)   
# (Intercept)            -0.017355   0.006447  -2.692  0.00806 **
#   wCov_Log2FC_AD_vs_Ctrl -0.202444   0.067340  -3.006  0.00318 **
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.07345 on 128 degrees of freedom
# (57 observations deleted due to missingness)
# Multiple R-squared:  0.06595,	Adjusted R-squared:  0.05865 
# F-statistic: 9.038 on 1 and 128 DF,  p-value: 0.003184

cor.test(metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad[metaOutputFDR_basic_and_cov$FDR<0.10], metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl[metaOutputFDR_basic_and_cov$FDR<0.10], method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad[metaOutputFDR_basic_and_cov$FDR < 0.1] and metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl[metaOutputFDR_basic_and_cov$FDR < 0.1]
# S = 437838, p-value = 0.02572
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#        rho 
# -0.1958049




#Dissection vs. Antidepressant effects:

pdf("Scatterplot_MetaAnalysisLog2FC_Dissection_vs_Original.pdf", height=5, width=4)
plot(metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC~metaOutputFDR_basic_and_cov$Log2FC_estimate, xlab="Antidepressant Log2FC: without Covariates", ylab="Dissection Log2FC")
#abline(a=0, b=1, col="grey", lwd=3)
TrendLine<-lm(metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC~metaOutputFDR_basic_and_cov$Log2FC_estimate)
abline(TrendLine, col=2, lwd=3)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC ~ 
#        metaOutputFDR_basic_and_cov$Log2FC_estimate)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -1.01262 -0.05409 -0.00122  0.05231  1.41385 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                                 -0.0083822  0.0007965  -10.52   <2e-16 ***
#   metaOutputFDR_basic_and_cov$Log2FC_estimate  1.2799373  0.0171219   74.75   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.102 on 16401 degrees of freedom
# (91 observations deleted due to missingness)
# Multiple R-squared:  0.2541,	Adjusted R-squared:  0.2541 
# F-statistic:  5588 on 1 and 16401 DF,  p-value: < 2.2e-16

cor.test(metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC, metaOutputFDR_basic_and_cov$Log2FC_estimate, method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC and metaOutputFDR_basic_and_cov$Log2FC_estimate
# S = 4.6895e+11, p-value < 2.2e-16
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.3624635


pdf("Scatterplot_MetaAnalysisLog2FC_Dissection_vs_Original_FDR10.pdf", height=6, width=5)
plot(wCov_Log2FC_Dissection_DG_vs_HPC~Log2FC_estimate, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,], xlab="Antidepressant Log2FC", ylab="Dissection Log2FC", pch=16, col="grey")
points(wCov_Log2FC_Dissection_DG_vs_HPC~Log2FC_estimate, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,])
TrendLine<-lm(wCov_Log2FC_Dissection_DG_vs_HPC~Log2FC_estimate, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,])
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = wCov_Log2FC_Dissection_DG_vs_HPC ~ Log2FC_estimate, 
#      data = metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR < 
#                                           0.1, ])
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.220882 -0.048500 -0.005184  0.046832  0.201225 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)     -0.012196   0.006148  -1.984   0.0494 *  
#   Log2FC_estimate  0.360062   0.061405   5.864 3.63e-08 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.06975 on 128 degrees of freedom
# (57 observations deleted due to missingness)
# Multiple R-squared:  0.2117,	Adjusted R-squared:  0.2056 
# F-statistic: 34.38 on 1 and 128 DF,  p-value: 3.629e-08


cor.test(metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC[metaOutputFDR_basic_and_cov$FDR<0.10], metaOutputFDR_basic_and_cov$Log2FC_estimate[metaOutputFDR_basic_and_cov$FDR<0.10], method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC[metaOutputFDR_basic_and_cov$FDR < 0.1] and metaOutputFDR_basic_and_cov$Log2FC_estimate[metaOutputFDR_basic_and_cov$FDR < 0.1]
# S = 240380, p-value = 6.98e-05
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.3434841 


pdf("Scatterplot_MetaAnalysisLog2FC_Dissection_vs_AD.pdf", height=5, width=4)
plot(metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC~metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl, xlab="Antidepressant Log2FC: with Covariates", ylab="Dissection Log2FC")
#abline(a=0, b=1, col="grey", lwd=3)
TrendLine<-lm(metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC~metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl)
abline(TrendLine, col=2, lwd=3)
dev.off()

summary.lm(TrendLine)


# Call:
#   lm(formula = metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC ~ 
#        metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.92820 -0.04697 -0.00094  0.04504  1.20670 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                                        -0.0055955  0.0007016  -7.975 1.62e-15 ***
#   metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl  1.3895700  0.0127368 109.099  < 2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.08987 on 16440 degrees of freedom
# (52 observations deleted due to missingness)
# Multiple R-squared:   0.42,	Adjusted R-squared:  0.4199 
# F-statistic: 1.19e+04 on 1 and 16440 DF,  p-value: < 2.2e-16


cor.test(metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC, metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl, method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC and metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl
# S = 3.7176e+11, p-value < 2.2e-16
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.4981798


pdf("Scatterplot_MetaAnalysisLog2FC__Dissection_vs_AD_FDR10.pdf", height=6, width=5)
plot(wCov_Log2FC_Dissection_DG_vs_HPC~wCov_Log2FC_AD_vs_Ctrl, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,], xlab="Antidepressant Log2FC", ylab="Dissection Log2FC", pch=16, col="grey")
points(wCov_Log2FC_Dissection_DG_vs_HPC~wCov_Log2FC_AD_vs_Ctrl, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,])
TrendLine<-lm(wCov_Log2FC_Dissection_DG_vs_HPC~wCov_Log2FC_AD_vs_Ctrl, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,])
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = wCov_Log2FC_Dissection_DG_vs_HPC ~ wCov_Log2FC_AD_vs_Ctrl, 
#      data = metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR < 
#                                           0.1, ])
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.196088 -0.044579  0.000295  0.040298  0.202083 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)            -0.010502   0.005675  -1.851   0.0665 .  
# wCov_Log2FC_AD_vs_Ctrl  0.463106   0.059271   7.813 1.77e-12 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.06465 on 128 degrees of freedom
# (57 observations deleted due to missingness)
# Multiple R-squared:  0.3229,	Adjusted R-squared:  0.3176 
# F-statistic: 61.05 on 1 and 128 DF,  p-value: 1.765e-12

cor.test(metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC[metaOutputFDR_basic_and_cov$FDR<0.10], metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl[metaOutputFDR_basic_and_cov$FDR<0.10], method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC[metaOutputFDR_basic_and_cov$FDR < 0.1] and metaOutputFDR_basic_and_cov$wCov_Log2FC_AD_vs_Ctrl[metaOutputFDR_basic_and_cov$FDR < 0.1]
# S = 175064, p-value = 2.34e-10
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.5218725



pdf("Scatterplot_MetaAnalysisLog2FC_Dissection_vs_ADtype.pdf", height=5, width=4)
plot(metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC~metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad, xlab="Antidepressant Type Log2FC", ylab="Dissection Log2FC")
#abline(a=0, b=1, col="grey", lwd=3)
TrendLine<-lm(metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC~metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad)
abline(TrendLine, col=2, lwd=3)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = metaOutputFDR_basic_and_cov$wCov_Log2FC_Dissection_DG_vs_HPC ~ 
#        metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -1.49714 -0.05068  0.00035  0.05320  1.54006 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)                                                  -0.0057078  0.0008922  -6.398 1.62e-10 ***
#   metaOutputFDR_basic_and_cov$wCov_Log2FC_ADType_NonTradvsTrad  0.4069450  0.0114737  35.468  < 2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.1137 on 16440 degrees of freedom
# (52 observations deleted due to missingness)
# Multiple R-squared:  0.07108,	Adjusted R-squared:  0.07102 
# F-statistic:  1258 on 1 and 16440 DF,  p-value: < 2.2e-16



pdf("Scatterplot_MetaAnalysisLog2FC_Dissection_vs_ADtype_FDR10.pdf", height=6, width=5)
plot(wCov_Log2FC_Dissection_DG_vs_HPC~wCov_Log2FC_ADType_NonTradvsTrad, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,], xlab="Antidepressant Type Log2FC", ylab="Dissection Log2FC", pch=16, col="grey")
points(wCov_Log2FC_Dissection_DG_vs_HPC~wCov_Log2FC_ADType_NonTradvsTrad, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,])
TrendLine<-lm(wCov_Log2FC_Dissection_DG_vs_HPC~wCov_Log2FC_ADType_NonTradvsTrad, data=metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR<0.10,])
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = wCov_Log2FC_Dissection_DG_vs_HPC ~ wCov_Log2FC_ADType_NonTradvsTrad, 
#      data = metaOutputFDR_basic_and_cov[metaOutputFDR_basic_and_cov$FDR < 
#                                           0.1, ])
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.197236 -0.047148 -0.004452  0.058099  0.288392 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)
# (Intercept)                      -0.006960   0.007059  -0.986    0.326
# wCov_Log2FC_ADType_NonTradvsTrad  0.092254   0.091010   1.014    0.313
# 
# Residual standard error: 0.07825 on 128 degrees of freedom
# (57 observations deleted due to missingness)
# Multiple R-squared:  0.007964,	Adjusted R-squared:  0.0002133 
# F-statistic: 1.028 on 1 and 128 DF,  p-value: 0.3127


#########################

#Checking on top genes:

#Are the top genes still significant after controlling for covariates?

sum(metaOutputFDR_basic_and_cov$FDR<0.05 & metaOutputFDR_basic_and_cov$wCov_AD_FDR<0.05, na.rm=TRUE)
#[1] 39

sum(metaOutputFDR_basic_and_cov$FDR<0.05 & metaOutputFDR_basic_and_cov$wCov_pval_AD<0.05, na.rm=TRUE)
#[1] 52
#So there are a handful of genes that aren't significant anymore after controlling for co-variates (either using nominal or FDR definitions)
#Let's see which those are:

metaOutputFDR_basic_and_cov$Mouse_Symbol[which(metaOutputFDR_basic_and_cov$FDR<0.05 & metaOutputFDR_basic_and_cov$wCov_pval_AD>0.05)]
#[1] "Glis1"  "Upk1a"  "Zfp324" "Lrrc1"  "Gbp2"   "Zfp773"

#So hypothetically those have differential expression that is driven more by either traditional ADs or whole HPC
#Which are more represented in the whole meta-analysis


#Is there any evidence that the top genes vary by AD type?

sum(metaOutputFDR_basic_and_cov$FDR<0.05 & metaOutputFDR_basic_and_cov$wCov_ADType_FDR<0.05, na.rm=TRUE)
#[1] 0

sum(metaOutputFDR_basic_and_cov$FDR<0.05 & metaOutputFDR_basic_and_cov$wCov_pval_ADType<0.05, na.rm=TRUE)
#[1] 5

#So weak evidence of variation by AD type for the top genes.

metaOutputFDR_basic_and_cov$Mouse_Symbol[which(metaOutputFDR_basic_and_cov$FDR<0.05 & metaOutputFDR_basic_and_cov$wCov_pval_ADType<0.05)]
#[1] "Ccl20"   "Cables1" "Lrrc1"   "Stxbp5"  "Fen1" 


#Is there any evidence that the top genes vary by dissection?

sum(metaOutputFDR_basic_and_cov$FDR<0.05 & metaOutputFDR_basic_and_cov$wCov_Dissection_FDR<0.05, na.rm=TRUE)
#[1] 3

metaOutputFDR_basic_and_cov$Mouse_Symbol[which(metaOutputFDR_basic_and_cov$FDR<0.05 & metaOutputFDR_basic_and_cov$wCov_Dissection_FDR<0.05)]
#[1] "Aff3"   "Rpp25l" "Relch" 

sum(metaOutputFDR_basic_and_cov$FDR<0.05 & metaOutputFDR_basic_and_cov$wCov_pval_Dissection<0.05, na.rm=TRUE)
#[1] 10

metaOutputFDR_basic_and_cov$Mouse_Symbol[which(metaOutputFDR_basic_and_cov$FDR<0.05 & metaOutputFDR_basic_and_cov$wCov_pval_Dissection<0.05)]
#[1] "Aff3"    "Fam135b" "Cdkn2d"  "Stxbp5"  "Rpp25l"  "Pea15a"  "Relch"   "Tbx19"   "Naa50"   "Plekha2"

pdf("Boxplot_I2_Heterogeneity_Original_vs_MetaRegression.pdf", height=5, width=4)
boxplot(data.frame(Original=metaOutputFDR_basic_and_cov$I2_PercentVar_TrueHeterogeneity, MetaRegression=metaOutputFDR_basic_and_cov$wCov_I2_PercentVar_TrueHeterogeneity), ylab="I2")
dev.off()

pdf("Histogram_ChangeInI2_MetaRegressionVsOriginal.pdf", height=4, width=5)
hist((metaOutputFDR_basic_and_cov$wCov_I2_PercentVar_TrueHeterogeneity-metaOutputFDR_basic_and_cov$I2_PercentVar_TrueHeterogeneity), breaks=100, xlab= "Change in I2: Meta-Regression vs. Original")
dev.off()

summary((metaOutputFDR_basic_and_cov$wCov_I2_PercentVar_TrueHeterogeneity-metaOutputFDR_basic_and_cov$I2_PercentVar_TrueHeterogeneity))
#    Min.  1st Qu.   Median     Mean  3rd Qu.     Max.     NA's 
# -85.7906  -8.1395  -1.0529  -5.1665   0.4858  95.6160       91 


#We should probably also compare these results to the traditional and non-traditional meta-analysis output

setwd("~/Library/CloudStorage/GoogleDrive-hagenaue@umich.edu/My Drive/BrainAlchemyProject/ProjectFolders/2024_EvaGeoghegan_Antidepressants_Hippocampus/ROutput_And_Results/Hen Lab Collab/Final_Results_Nov18")

TradOnly<-read.csv("Traditional_Only_metaOutputFDR_orderedByPval.csv", header=TRUE, stringsAsFactors = FALSE)

setwd("~/Library/CloudStorage/GoogleDrive-hagenaue@umich.edu/My Drive/BrainAlchemyProject/ProjectFolders/2024_EvaGeoghegan_Antidepressants_Hippocampus/ROutput_And_Results/Hen Lab Collab/NonTrad Only")

NonTradOnly<-read.csv("Nontrad_metaOutputFDR_orderedByPval.csv", header=TRUE, stringsAsFactors = FALSE)

setwd("~/Library/CloudStorage/GoogleDrive-hagenaue@umich.edu/My Drive/BrainAlchemyProject/ProjectFolders/2024_EvaGeoghegan_Antidepressants_Hippocampus/ROutput_And_Results/Revisions")


str(metaOutputFDR_basic_and_cov)
#'data.frame':	16494 obs. of  76 variables:

#$ MouseVsRat_EntrezGene.ID 

colnames(TradOnly)
#[11] "MouseVsRat_EntrezGene.ID" 

colnames(TradOnly)[-11]<-paste("Trad", colnames(TradOnly)[-11], sep="_")

colnames(NonTradOnly)
#[11] "MouseVsRat_EntrezGene.ID" 

colnames(NonTradOnly)[-11]<-paste("NonTrad", colnames(NonTradOnly)[-11], sep="_")

library(plyr)

metaOutputFDR_basic_and_cov_wTradNonTrad<-join_all(list(metaOutputFDR_basic_and_cov, TradOnly, NonTradOnly), by="MouseVsRat_EntrezGene.ID", type="left")

write.csv(metaOutputFDR_basic_and_cov_wTradNonTrad, "metaOutputFDR_basic_and_cov_wTradNonTrad.csv")

pdf("Plot_TradVsNonTrad_TopMetaGenes_FDR05.pdf", height=6, width=5)
plot(NonTrad_Log2FC_estimate~Trad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.05,], xlab="Traditional Antidepressants: Log2FC", ylab="Non-Traditional Antidepressants: Log2FC", pch=16, col="grey")
points(NonTrad_Log2FC_estimate~Trad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.05,])
TrendLine<-lm(NonTrad_Log2FC_estimate~Trad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.05,])
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

sum(metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.05, na.rm=TRUE)

# Call:
#   lm(formula = NonTrad_Log2FC_estimate ~ Trad_Log2FC_estimate, 
#      data = metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 
#                                                        0.05, ])

# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.08913 -0.02067 -0.01146  0.01594  0.10820 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)          -0.007289   0.009085  -0.802    0.431    
# Trad_Log2FC_estimate  0.523041   0.084488   6.191 3.13e-06 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.04352 on 22 degrees of freedom
# (90 observations deleted due to missingness)
# Multiple R-squared:  0.6353,	Adjusted R-squared:  0.6187 
# F-statistic: 38.32 on 1 and 22 DF,  p-value: 3.131e-06

cor.test(metaOutputFDR_basic_and_cov_wTradNonTrad$NonTrad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.05], metaOutputFDR_basic_and_cov_wTradNonTrad$Trad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.05], method="spearman", use="pairwise.complete.obs")
# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov_wTradNonTrad$NonTrad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 0.05] and metaOutputFDR_basic_and_cov_wTradNonTrad$Trad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 0.05]
# S = 764, p-value = 0.0005018
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.6678261 


pdf("Plot_TradVsNonTrad_TopMetaGenes_FDR10.pdf", height=6, width=5)
plot(NonTrad_Log2FC_estimate~Trad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10,], xlab="Traditional Antidepressants: Log2FC", ylab="Non-Traditional Antidepressants: Log2FC", pch=16, col="grey")
points(NonTrad_Log2FC_estimate~Trad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10,])
TrendLine<-lm(NonTrad_Log2FC_estimate~Trad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10,])
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = NonTrad_Log2FC_estimate ~ Trad_Log2FC_estimate, 
#      data = metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 
#                                                        0.1, ])
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.087407 -0.017900 -0.006606  0.014547  0.110255 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)          -0.008150   0.004579   -1.78   0.0801 .  
# Trad_Log2FC_estimate  0.532779   0.047170   11.29   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.03546 on 61 degrees of freedom
# (124 observations deleted due to missingness)
# Multiple R-squared:  0.6765,	Adjusted R-squared:  0.6712 
# F-statistic: 127.6 on 1 and 61 DF,  p-value: < 2.2e-16

cor.test(metaOutputFDR_basic_and_cov_wTradNonTrad$NonTrad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10], metaOutputFDR_basic_and_cov_wTradNonTrad$Trad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10], method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov_wTradNonTrad$NonTrad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 0.1] and metaOutputFDR_basic_and_cov_wTradNonTrad$Trad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 0.1]
# S = 10710, p-value < 2.2e-16
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.7429435


#How about the meta-regression estimates vs. the subsetted meta-analyses?


metaOutputFDR_basic_and_cov_wTradNonTrad$TradMetaRegression_Log2FC<-metaOutputFDR_basic_and_cov_wTradNonTrad$wCov_Log2FC_AD_vs_Ctrl-(0.5*metaOutputFDR_basic_and_cov_wTradNonTrad$wCov_Log2FC_ADType_NonTradvsTrad)

metaOutputFDR_basic_and_cov_wTradNonTrad$NonTradMetaRegression_Log2FC<-metaOutputFDR_basic_and_cov_wTradNonTrad$wCov_Log2FC_AD_vs_Ctrl+(0.5*metaOutputFDR_basic_and_cov_wTradNonTrad$wCov_Log2FC_ADType_NonTradvsTrad)

pdf("Plot_TradMetaRegressionVsTrad_TopMetaGenes_FDR10.pdf", height=6, width=5)
plot(TradMetaRegression_Log2FC~Trad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10,], xlab="Traditional Antidepressants: Log2FC (Subsetted Meta)", ylab="Traditional Antidepressants: Log2FC (Meta-Regression)")
TrendLine<-lm(TradMetaRegression_Log2FC~Trad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10,])
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = TradMetaRegression_Log2FC ~ Trad_Log2FC_estimate, 
#      data = metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 
#                                                        0.1, ])
# 
# Residuals:
#   Min         1Q     Median         3Q        Max 
# -0.0198332 -0.0053058  0.0000393  0.0057322  0.0199874 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)          0.0004111  0.0010625   0.387      0.7    
# Trad_Log2FC_estimate 0.9823498  0.0109243  89.923   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.008225 on 61 degrees of freedom
# (124 observations deleted due to missingness)
# Multiple R-squared:  0.9925,	Adjusted R-squared:  0.9924 
# F-statistic:  8086 on 1 and 61 DF,  p-value: < 2.2e-16


cor.test(metaOutputFDR_basic_and_cov_wTradNonTrad$TradMetaRegression_Log2FC[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10], metaOutputFDR_basic_and_cov_wTradNonTrad$Trad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10], method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov_wTradNonTrad$TradMetaRegression_Log2FC[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 0.1] and metaOutputFDR_basic_and_cov_wTradNonTrad$Trad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 0.1]
# S = 836, p-value < 2.2e-16
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.9799347 


pdf("Plot_TradMetaRegressionVsTrad_TopMetaGenes_AllGenes.pdf", height=6, width=5)
plot(TradMetaRegression_Log2FC~Trad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad, xlab="Traditional Antidepressants: Log2FC (Subsetted Meta)", ylab="Traditional Antidepressants: Log2FC (Meta-Regression)")
TrendLine<-lm(TradMetaRegression_Log2FC~Trad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad)
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = TradMetaRegression_Log2FC ~ Trad_Log2FC_estimate, 
#      data = metaOutputFDR_basic_and_cov_wTradNonTrad)
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.176424 -0.006734  0.000362  0.007288  0.110257 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)          -0.0001762  0.0001592  -1.106    0.269    
# Trad_Log2FC_estimate  0.9322234  0.0025073 371.811   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.0156 on 9594 degrees of freedom
# (6898 observations deleted due to missingness)
# Multiple R-squared:  0.9351,	Adjusted R-squared:  0.9351 
# F-statistic: 1.382e+05 on 1 and 9594 DF,  p-value: < 2.2e-16


cor.test(metaOutputFDR_basic_and_cov_wTradNonTrad$TradMetaRegression_Log2FC, metaOutputFDR_basic_and_cov_wTradNonTrad$Trad_Log2FC_estimate, method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov_wTradNonTrad$TradMetaRegression_Log2FC and metaOutputFDR_basic_and_cov_wTradNonTrad$Trad_Log2FC_estimate
# S = 6714739662, p-value < 2.2e-16
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.9544058 


pdf("Plot_NonTradMetaRegressionVsNonTrad_TopMetaGenes_FDR10.pdf", height=6, width=5)
plot(NonTradMetaRegression_Log2FC~NonTrad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10,], xlab="Non-Traditional Antidepressants: Log2FC (Subsetted Meta)", ylab="Non-Traditional Antidepressants: Log2FC (Meta-Regression)")
TrendLine<-lm(NonTradMetaRegression_Log2FC~NonTrad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10,])
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = NonTradMetaRegression_Log2FC ~ NonTrad_Log2FC_estimate, 
#      data = metaOutputFDR_basic_and_cov_wTradNonTrad[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 
#                                                        0.1, ])
# 
# Residuals:
#   Min        1Q    Median        3Q       Max 
# -0.091975 -0.017366  0.002463  0.017018  0.051985 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)             -0.007421   0.002883  -2.574   0.0118 *  
#   NonTrad_Log2FC_estimate  1.062002   0.041429  25.635   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.02623 on 85 degrees of freedom
# (100 observations deleted due to missingness)
# Multiple R-squared:  0.8855,	Adjusted R-squared:  0.8841 
# F-statistic: 657.1 on 1 and 85 DF,  p-value: < 2.2e-16

cor.test(metaOutputFDR_basic_and_cov_wTradNonTrad$NonTradMetaRegression_Log2FC[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10], metaOutputFDR_basic_and_cov_wTradNonTrad$NonTrad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR<0.10], method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov_wTradNonTrad$NonTradMetaRegression_Log2FC[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 0.1] and metaOutputFDR_basic_and_cov_wTradNonTrad$NonTrad_Log2FC_estimate[metaOutputFDR_basic_and_cov_wTradNonTrad$FDR < 0.1]
# S = 8350, p-value < 2.2e-16
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.9239083 



pdf("Plot_NonTradMetaRegressionVsNonTrad_TopMetaGenes_All.pdf", height=6, width=5)
plot(NonTradMetaRegression_Log2FC~NonTrad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad, xlab="Non-Traditional Antidepressants: Log2FC (Subsetted Meta)", ylab="Non-Traditional Antidepressants: Log2FC (Meta-Regression)")
TrendLine<-lm(NonTradMetaRegression_Log2FC~NonTrad_Log2FC_estimate, data=metaOutputFDR_basic_and_cov_wTradNonTrad)
abline(TrendLine, lwd=3, col=2)
dev.off()

summary.lm(TrendLine)

# Call:
#   lm(formula = NonTradMetaRegression_Log2FC ~ NonTrad_Log2FC_estimate, 
#      data = metaOutputFDR_basic_and_cov_wTradNonTrad)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.32837 -0.01798 -0.00016  0.01875  0.19334 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)             -0.0039125  0.0002989  -13.09   <2e-16 ***
#   NonTrad_Log2FC_estimate  1.1306917  0.0084290  134.14   <2e-16 ***
#   ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# 
# Residual standard error: 0.03282 on 12123 degrees of freedom
# (4369 observations deleted due to missingness)
# Multiple R-squared:  0.5975,	Adjusted R-squared:  0.5974 
# F-statistic: 1.799e+04 on 1 and 12123 DF,  p-value: < 2.2e-16


cor.test(metaOutputFDR_basic_and_cov_wTradNonTrad$NonTradMetaRegression_Log2FC, metaOutputFDR_basic_and_cov_wTradNonTrad$NonTrad_Log2FC_estimate, method="spearman", use="pairwise.complete.obs")

# Spearman's rank correlation rho
# 
# data:  metaOutputFDR_basic_and_cov_wTradNonTrad$NonTradMetaRegression_Log2FC and metaOutputFDR_basic_and_cov_wTradNonTrad$NonTrad_Log2FC_estimate
# S = 6.5514e+10, p-value < 2.2e-16
# alternative hypothesis: true rho is not equal to 0
# sample estimates:
#       rho 
# 0.7794823


###############

#Making some more forest plots

source("Function_MakeForestPlots_AdjustedForHPC.R")

metaOutputFDR_OrderbyPval$Mouse_EntrezGene.ID[which(metaOutputFDR_OrderbyPval$Mouse_Symbol=="Bdnf")]
MakeForestPlots(metaOutputFDR_annotated, EntrezIDAsCharacter="12064", species="Mouse") 

metaOutputFDR_OrderbyPval$Mouse_EntrezGene.ID[which(metaOutputFDR_OrderbyPval$Mouse_Symbol=="Thra")]
MakeForestPlots(metaOutputFDR_annotated, EntrezIDAsCharacter="21833", species="Mouse") 


metaOutputFDR_OrderbyPval$Mouse_EntrezGene.ID[which(metaOutputFDR_OrderbyPval$Mouse_Symbol=="Lsr")]
MakeForestPlots(metaOutputFDR_annotated, EntrezIDAsCharacter="54135", species="Mouse") 

metaOutputFDR_OrderbyPval$Mouse_EntrezGene.ID[which(metaOutputFDR_OrderbyPval$Mouse_Symbol=="Tmem144")]
MakeForestPlots(metaOutputFDR_annotated, EntrezIDAsCharacter="70652", species="Mouse") 

metaOutputFDR_OrderbyPval$Mouse_EntrezGene.ID[which(metaOutputFDR_OrderbyPval$Mouse_Symbol=="Mfge8")]
MakeForestPlots(metaOutputFDR_annotated, EntrezIDAsCharacter="17304", species="Mouse") 
